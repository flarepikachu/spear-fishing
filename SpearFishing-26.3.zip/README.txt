Spear Fishing 26.3 Resource Pack

Troubletoads now use Minecraft's native Frog model and data-driven frog variants. The pack contains five 48x48 frog UV textures: vanilla green (Base), vanilla white (Cherry), vanilla orange (Desert), the provided brown atlas (Swamp), and the provided blue atlas (Snow). The plugin uses the matching custom frog variant ID, so every vanilla client renders the real 3D frog with the UV texture.

The companion data pack is in `work/spear-fishing/datapacks/SpearFishingFrogVariants`. It must be installed in the server world's `datapacks` folder and enabled before Troubletoads spawn. This project also installs it into the local `boss-test-world`.

For remote delivery, upload `SpearFishing-26.3.zip` to the GitHub repository, then configure the resulting direct HTTPS download URL and the ZIP's SHA-1 in `server.properties`.
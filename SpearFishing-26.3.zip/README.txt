Spear Fishing 26.3 Resource Pack

This pack adds client-side textures for Troubletoad's five variants and sets up a name-based texture framework for future custom mobs.

Troubletoad skins:
- Base: vanilla green frog
- Cherry: vanilla white frog
- Desert: vanilla orange frog
- Swamp: pixel-recolored brown frog
- Snow: pixel-recolored blue frog

The Brown and Blue skins are 48x48 textures. Generate-FrogVariants.ps1 rebuilds them from the vanilla 26.1 frog UV maps while preserving every pixel position and alpha value, changing only selected palette colors.

The texture rules use the hidden names emitted by SpearFishing. They require OptiFine Random Entities support. Vanilla Minecraft resource packs cannot select a mob texture by its hidden custom name. Clients without compatible Random Entities support can still use the plugin; they will see vanilla frog colors, while the plugin nameplate/glow colors remain distinct.

Client installation: put SpearFishing-26.3.zip in the Minecraft resourcepacks folder and enable it in Options > Resource Packs.

Server distribution is separate. To prompt other players, host the ZIP at an HTTP(S) URL and configure that URL and its SHA-1 in server.properties. Do not use a local filesystem path for server resource-pack delivery.

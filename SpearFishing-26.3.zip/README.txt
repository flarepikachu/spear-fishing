Spear Fishing 26.3 Resource Pack

This pack includes vanilla-compatible item models used as Troubletoad displays by the SpearFishing plugin. No OptiFine, ETF, or client mod is needed for the Troubletoad display models. The plugin keeps the native frog visible until a client reports that the server pack loaded successfully.

Troubletoad variants: Base (green), Cherry (white), Desert (orange), Swamp (brown), and Snow (blue). Each model uses a matching pixel-art sprite. Clients who decline or fail to load the server pack see the corresponding native Minecraft frog variant as a fallback.

For server delivery, configure the ZIP's direct HTTPS download URL and SHA-1 in server.properties. A GitHub blob page is not a direct ZIP link; use the repository's raw/download URL. After changing server.properties and installing the plugin, restart the server so it sends the pack to players.
